from setuptools import setup, find_packages  
    
setup(name='MyLibrary',
      version='1.0',
      py_modules=['MyLibrary'],
      packages = find_packages(),
    ) 