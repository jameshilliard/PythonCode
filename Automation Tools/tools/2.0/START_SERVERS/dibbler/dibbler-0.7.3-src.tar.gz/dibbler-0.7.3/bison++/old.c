/* JF changed to accept/deal with variable args.
   DO NOT change this to use varargs.  It will appear to work
   but will break on systems that don't have the necessary library
   functions.  This is the ONLY safe way to write such a function.  */
/*VARARGS1*/
#include <stdio.h>
