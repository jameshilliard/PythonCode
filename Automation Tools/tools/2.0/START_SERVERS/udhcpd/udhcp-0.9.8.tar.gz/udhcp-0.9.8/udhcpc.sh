vconfig add eth0 201
ifconfig eth0.201 up
ifconfig eth0.201 192.168.16.4 netmask 255.255.255.0

./udhcpc -f -i eth1 -s /usr/share/udhcpc/sample.script
