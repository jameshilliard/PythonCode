package org.testng.xslt.test;

/**
 * @author Cosmin Marginean, Jun 13, 2008
 */
public class SomeClass {
}
